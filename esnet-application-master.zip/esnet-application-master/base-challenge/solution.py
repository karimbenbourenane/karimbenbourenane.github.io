#!/usr/bin/env python

"""
Given a list of files with their sizes and a list of compute nodes with their
available space, this program produces a distribution plan of how to place the
files on the nodes. The plan makes the total amount of data distributed to
each node as balanced as reasonably possible.
In the case where not all the input data will fit on the nodes, this program
places what data it can, and the output will indicate which files were not
included in the plan.
"""

from getopt import getopt, GetoptError
from sys import argv, exit


def usage():
    """
    Prints out the acceptable options and parameters for this utility.
    :return: None
    """

    print("usage: python solution.py -f file.txt -n nodes.txt [-o output.txt]")


def filename_to_data_list(filename):
    """
    Opens a named file and parses it to extract pairs of names and sizes.
    :param filename: Name of file to be consumed to produce a paired data list.
    :return: List of lists that contains pairs of names and sizes.
    """

    data = list()

    with open(filename, 'r') as file:
        for line in file:
            if line.startswith('#'):
                # Lines that begin with "#" are comments, therefore omitted.
                continue
            # In case of a file that contains spaces in its name, we split only
            # on the right most space to retain the full filename.
            tokens = line.strip().rsplit(' ', 1)
            data.append([tokens[0], int(tokens[1])])

    return data


def distribute(input_files_filename, input_nodes_filename, output_filename):
    """
    Given an input of files and and input of nodes, allocate each file to a
    node such that the
    :param input_files_filename: Filename that contains file names and sizes.
    :param input_nodes_filename: Filename that contains node names and sizes.
    :param output_filename: Filename to which node distributions are written.
    :return: None
    """

    files = filename_to_data_list(input_files_filename)

    # Set file to node assignments originally to 'NULL', then determine the
    # correct assignments for assignable files later.
    assignments = {f[0]: 'NULL' for f in files}

    # Sort files from largest to smallest.
    files_sorted = sorted(files, key=lambda x: x[1], reverse=True)
    nodes = filename_to_data_list(input_nodes_filename)

    # Sort nodes from smallest to largest.
    nodes_sorted = sorted(nodes, key=lambda x: x[1])

    # Annotate nodes with allocated space and free space, respectively.
    nodes_annotated = [[node, 0, node[1]] for node in nodes_sorted]

    for file in files_sorted:
        """
        Iterate through files, starting from largest to smallest. For each 
        file, iterate through nodes from least allocated to most allocated 
        space. If the file fits on that node, allocate it and assign it, then 
        resort the nodes from least allocated to most allocated. Repeat this 
        process until all files exhausted. Any files that are unallocated at 
        the end of this routine will remain with an assignment of 'NULL'.
        """

        for node in nodes_annotated:
            if file[1] <= node[2]:  # Node found; adjust space and assign.
                node[1] += file[1]
                node[2] -= file[1]
                assignments[file[0]] = node[0][0]
                # Since acceptable node was found, resort the nodes.
                nodes_annotated.sort(key=lambda x: x[1])
                break

    lines = [file[0] + ' ' + assignments[file[0]] for file in files]

    if output_filename:
        # Print output to named output file.
        with open(output_filename, 'w') as output_file:
            for line in lines:
                output_file.write("%s\n" % line)
    else:
        # No output file specified; print output to stdout.
        for line in lines:
            print(line)


def main():
    """
    Main method for handling command line arguments, then passing those to the
    inputs to the distribute method.
    :return: None
    """

    opts = None  # suppress warning satisfied by except in following try block.

    try:
        opts, args = getopt(argv[1:], 'f:n:o:')
    except GetoptError as err:
        # Bad option provided; print error provide correct usage, then exit.
        print(str(err))
        usage()
        exit(1)

    input_files_filename = None
    input_nodes_filename = None
    output_filename = None

    for opt, arg in opts:
        if opt == '-f':
            input_files_filename = arg
        elif opt == '-n':
            input_nodes_filename = arg
        elif opt == "-o":
            output_filename = arg
        else:  # Unrecognized option has occurred; show error message and exit.
            print(argv[0] + ": illegal option -- " + arg)
            exit(1)

    if not (input_files_filename and input_nodes_filename):
        # Required inputs not provided; print usage and then exit.
        usage()
        exit(1)

    # All input parameters correct, commence with computing distribution.
    distribute(input_files_filename, input_nodes_filename, output_filename)


if __name__ == '__main__':
    main()
