import React from 'react';
import './App.css';

const tokens = {
    tokens: 0,
    getToken: function () {
        tokens.tokens += 1;
        tokens.updateHTML();
    },
    updateHTML: function () {
        document.getElementById("tokens").innerHTML = tokens.tokens;
    },
}

function startAutomatic() {
    console.log("Starting automatic token acquisition...");
    setInterval(function(){
        tokens.getToken();
    }, 1000);
}

window.addEventListener("DOMContentLoaded", (event) => {
    tokens.updateHTML();
});

function App() {
    return (
        <html>
        <head>
            <title>What?</title>
        </head>
        <body>
        <h1>Hello</h1>
        <p>
            You have <span id="tokens"></span> tokens! </p>
        <form action="#">
            <button id="anotherToken" onClick={tokens.getToken}>Get another token!</button>
            <button id="tokenPerSecond" onClick={startAutomatic}>Get a token every second!</button>
        </form>
        </body>
        </html>
    );
}

export default App;
